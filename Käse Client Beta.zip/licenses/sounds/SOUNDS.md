# Sounds for Käse Client

All files in this folder were generated synthetically with a Python script (numpy/scipy) for this project.
No third-party samples, recordings or music are used, so there are no external licenses to list.

| File | Type | Notes |
|---|---|---|
| click_1_soft.ogg | UI click | soft, dull tap, lowered by 9 dB |
| click_2_glass.ogg | UI click | bright glass "tink", lowered by 9 dB |
| click_5_whisper.ogg | UI click | very quiet tick |
| music_1_ambient_calm_loop.ogg | music loop | ambient pads, 24 s, built as a seamless loop, about -26 LUFS |
| music_2_lofi_chill_loop.ogg | music loop | lo-fi with soft beat, 24.6 s, seamless loop, about -26 LUFS |
| music_3_synthwave_loop.ogg | music loop | synthwave, 19.2 s, seamless loop, about -26 LUFS |

Format: OGG Vorbis, mono, 44.1 kHz.
Target folder in the project: src/main/resources/assets/kaese_client/sounds/
