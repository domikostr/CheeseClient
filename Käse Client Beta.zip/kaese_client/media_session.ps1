# Käse Client - Dynamic Island helper (Windows only).
# Reads the Windows media session (the same one the Windows volume popup shows) and controls it.
# Started once by the client; stays running while the island is on and ends when the client
# closes its input. Nothing is sent anywhere: it only talks to Windows and to the client.
#
# Input (one command per line): toggle | next | previous | any 1 | any 0
# Output (one JSON object per line): the current media state, {} when nothing plays.
# The cover (base64) is only sent when the track changes.
#
# The work is done in C#, compiled here once with the C# compiler that comes with Windows. It
# uses only the WinRT metadata files every Windows has (System32\WinMetadata) and none of the
# .NET helpers (AsTask, AsStreamForRead), which need the SDK-only Windows.winmd.

$ErrorActionPreference = 'Stop'

$code = @'
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;
using Windows.Foundation;
using Windows.Media.Control;
using Windows.Storage.Streams;

public static class KaeseMediaSession {
    private static readonly Queue<string> Commands = new Queue<string>();
    private static volatile bool inputClosed;
    private static bool anyApp;

    /** PowerShell runs scripts on an STA thread, where the cover stream never finishes opening: work on an MTA thread. */
    public static void Start() {
        var worker = new Thread(Run);
        worker.SetApartmentState(ApartmentState.MTA);
        worker.Start();
        worker.Join();
    }

    private static void Run() {
        var output = new StreamWriter(Console.OpenStandardOutput(), new UTF8Encoding(false));
        output.AutoFlush = true;
        var reader = new Thread(ReadInput);
        reader.IsBackground = true;
        reader.Start();

        var manager = Wait(GlobalSystemMediaTransportControlsSessionManager.RequestAsync());
        if (manager == null) {
            return;
        }
        string lastTrack = null;
        string lastLine = null;
        int lastSent = 0;
        int nextRead = 0;
        while (!inputClosed) {
            string command;
            while ((command = NextCommand()) != null) {
                Handle(manager, command);
                nextRead = 0;
            }
            int now = Environment.TickCount;
            if (now - nextRead >= 0) {
                try {
                    string cover = null;
                    string line = State(manager, ref lastTrack, ref cover);
                    // only when something changed (or every few seconds, so the client knows this still runs)
                    if (cover != null || line != lastLine || now - lastSent > 3000) {
                        output.WriteLine(cover == null ? line : line.Substring(0, line.Length - 1) + ",\"cover\":\"" + cover + "\"}");
                        lastLine = line;
                        lastSent = now;
                    }
                } catch (Exception) {
                    // the media app went away in the middle of a read: try again next time
                }
                nextRead = now + 700;
            }
            Thread.Sleep(100);
        }
    }

    private static void ReadInput() {
        var input = new StreamReader(Console.OpenStandardInput(), Encoding.UTF8);
        string line;
        while ((line = input.ReadLine()) != null) {
            lock (Commands) {
                Commands.Enqueue(line.Trim());
            }
        }
        // the client closed its side: stop
        inputClosed = true;
    }

    private static string NextCommand() {
        lock (Commands) {
            return Commands.Count > 0 ? Commands.Dequeue() : null;
        }
    }

    private static void Handle(GlobalSystemMediaTransportControlsSessionManager manager, string command) {
        try {
            if (command == "any 1") { anyApp = true; return; }
            if (command == "any 0") { anyApp = false; return; }
            var session = Find(manager);
            if (session == null) {
                return;
            }
            if (command == "toggle") { Wait(session.TryTogglePlayPauseAsync()); }
            else if (command == "next") { Wait(session.TrySkipNextAsync()); }
            else if (command == "previous") { Wait(session.TrySkipPreviousAsync()); }
        } catch (Exception) {
            // a failed command must not end the helper
        }
    }

    /** Spotify first; other apps (browsers, players) only when allowed. */
    private static GlobalSystemMediaTransportControlsSession Find(GlobalSystemMediaTransportControlsSessionManager manager) {
        foreach (var session in manager.GetSessions()) {
            if (session.SourceAppUserModelId != null && session.SourceAppUserModelId.IndexOf("spotify", StringComparison.OrdinalIgnoreCase) >= 0) {
                return session;
            }
        }
        return anyApp ? manager.GetCurrentSession() : null;
    }

    private static string State(GlobalSystemMediaTransportControlsSessionManager manager, ref string lastTrack, ref string cover) {
        var session = Find(manager);
        var properties = session == null ? null : Wait(session.TryGetMediaPropertiesAsync());
        if (properties == null || string.IsNullOrEmpty(properties.Title)) {
            lastTrack = null;
            return "{}";
        }
        var playback = session.GetPlaybackInfo();
        var timeline = session.GetTimelineProperties();
        string track = properties.Title + "|" + properties.Artist + "|" + properties.AlbumTitle;
        if (track != lastTrack) {
            lastTrack = track;
            cover = ReadCover(properties.Thumbnail);
        }
        var json = new StringBuilder("{");
        json.Append("\"title\":").Append(Quote(properties.Title));
        json.Append(",\"artist\":").Append(Quote(properties.Artist));
        json.Append(",\"playing\":").Append(playback.PlaybackStatus == GlobalSystemMediaTransportControlsSessionPlaybackStatus.Playing ? "true" : "false");
        json.Append(",\"position\":").Append((long) timeline.Position.TotalMilliseconds);
        json.Append(",\"duration\":").Append((long) (timeline.EndTime - timeline.StartTime).TotalMilliseconds);
        json.Append(",\"updated\":").Append(timeline.LastUpdatedTime.ToUnixTimeMilliseconds());
        json.Append(",\"app\":").Append(Quote(session.SourceAppUserModelId));
        json.Append(",\"track\":").Append(Quote(track));
        return json.Append("}").ToString();
    }

    private static string ReadCover(IRandomAccessStreamReference reference) {
        if (reference == null) {
            return null;
        }
        using (var stream = Wait(reference.OpenReadAsync())) {
            if (stream == null) {
                return null;
            }
            // some apps report no size: read in blocks until the stream ends
            using (var data = new DataReader(stream))
            using (var bytes = new MemoryStream()) {
                data.InputStreamOptions = InputStreamOptions.Partial;
                while (bytes.Length < 8 * 1024 * 1024) {
                    uint loaded = Wait(data.LoadAsync(64 * 1024));
                    if (loaded == 0) {
                        break;
                    }
                    var block = new byte[loaded];
                    data.ReadBytes(block);
                    bytes.Write(block, 0, block.Length);
                }
                return bytes.Length == 0 ? null : Convert.ToBase64String(bytes.ToArray());
            }
        }
    }

    /** Waits for a WinRT operation without the .NET Task bridge; default on failure or after 3 s. */
    private static T Wait<T>(IAsyncOperation<T> operation) {
        int until = Environment.TickCount + 3000;
        while (operation.Status == AsyncStatus.Started) {
            if (Environment.TickCount - until >= 0) {
                operation.Cancel();
                return default(T);
            }
            Thread.Sleep(5);
        }
        return operation.Status == AsyncStatus.Completed ? operation.GetResults() : default(T);
    }

    private static string Quote(string text) {
        if (text == null) {
            return "null";
        }
        var builder = new StringBuilder("\"");
        foreach (char c in text) {
            switch (c) {
                case '"': builder.Append("\\\""); break;
                case '\\': builder.Append("\\\\"); break;
                case '\n': builder.Append("\\n"); break;
                case '\r': builder.Append("\\r"); break;
                case '\t': builder.Append("\\t"); break;
                default:
                    if (c < ' ') { builder.Append("\\u").Append(((int) c).ToString("x4")); } else { builder.Append(c); }
                    break;
            }
        }
        return builder.Append('"').ToString();
    }
}
'@

$runtime = [System.Runtime.InteropServices.RuntimeEnvironment]::GetRuntimeDirectory()
$metadata = Join-Path $env:windir 'System32\WinMetadata'
$parameters = New-Object System.CodeDom.Compiler.CompilerParameters
$parameters.GenerateInMemory = $true
foreach ($reference in @(
		'System.dll',
		(Join-Path $runtime 'System.Runtime.dll'),
		(Join-Path $runtime 'System.Runtime.InteropServices.WindowsRuntime.dll'),
		(Join-Path $metadata 'Windows.Foundation.winmd'),
		(Join-Path $metadata 'Windows.Media.winmd'),
		(Join-Path $metadata 'Windows.Storage.winmd'))) {
	[void] $parameters.ReferencedAssemblies.Add($reference)
}
$result = (New-Object Microsoft.CSharp.CSharpCodeProvider).CompileAssemblyFromSource($parameters, $code)
if ($result.Errors.HasErrors) {
	foreach ($compileError in $result.Errors) {
		[Console]::Error.WriteLine($compileError.ToString())
	}
	exit 2
}
$result.CompiledAssembly.GetType('KaeseMediaSession').GetMethod('Start').Invoke($null, @())
